<?php

namespace App\Repository;

use App\Entity\Packjetons;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Packjetons|null find($id, $lockMode = null, $lockVersion = null)
 * @method Packjetons|null findOneBy(array $criteria, array $orderBy = null)
 * @method Packjetons[]    findAll()
 * @method Packjetons[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class PackjetonsRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Packjetons::class);
    }

    // /**
    //  * @return Packjetons[] Returns an array of Packjetons objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('p')
            ->andWhere('p.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('p.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Packjetons
    {
        return $this->createQueryBuilder('p')
            ->andWhere('p.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
