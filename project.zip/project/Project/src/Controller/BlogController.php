<?php

namespace App\Controller;

use App\Entity\Produit;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class BlogController extends AbstractController
{
    /**
     * @Route("/blog", name="blog")
     */
    public function index()
    {
        return $this->render('blog/index.html.twig', [
            'controller_name' => 'BlogController',
        ]);
    }

    /**
     * @Route("/",name="home")
     */
    public function home(){
        return $this->render('blog/home.html.twig');
    }

    /**
     * @Route("/anchor", name="anchor")
     */
    public function anchor(){

        $repo = $this->getDoctrine()->getRepository(Produit::class);

        $produits = $repo->findAll();

        return $this->render('blog/anchor.html.twig',[
            "produits" => $produits
        ]);    
    }
    /**
     * @Route("/jetons",name="jetons")
     */
    public function jetons(){
        return $this->render('blog/jetons.html.twig');
    }
    /**
     * @Route("/help",name="help")
     */
    public function help(){
        return $this->render('blog/help.html.twig');
    }
   
}
