<?php

namespace App\DataFixtures;

use App\Entity\Produit;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class ProduitFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);
        for($i = 1; $i <= 10; $i++){
            $produit = new Produit();
            $produit->setReference("reference de l'article n°$i")
                    ->setDescriptif("<p>contenu de l'article n°$i</p>")
                    ->setPrix("0.89")
                    ->setImage("http://placehold.it/150x350");
                    

            $manager->persist($produit);
        }


        $manager->flush();
    }
}
