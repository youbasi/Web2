<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/jetons.html.twig */
class __TwigTemplate_1c56bf916b3fa53050fe37fb49261b5ffa25f379d938830e9f9734a8b7c5b6df extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/jetons.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/jetons.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog/jetons.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <center><h1> Pack jetons <img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"></h1></center>
    </br>
    </br>
    <center>
    <table>
         <tr>
            <th><img width=\"350\" height=\"400\" alt=\"\" src=\"http://getdrawings.com/vectors/gold-coin-vector-34.jpg\"></th>
            <th><h1> &ensp;</h1></th>
            <th><img width=\"350\" height=\"400\" alt=\"\" src=\"http://getdrawings.com/vectors/gold-coin-vector-11.jpg\" ></th>
            <th><h1> &ensp;</h1></th>
            <th><img width=\"350\" height=\"400\" alt=\"\" src=\"http://getdrawings.com/vectors/gold-coin-vector-33.jpg\"></th>
            <th></br></th>
         </tr>   
    </table>
    <table>
        <tr>
            <th><p1> Le pack gold va te permettre de vivre une expérience ultime sur notre site d'enchére, tu vas recevoir 5.000 jetons juste a 99.99 euros </p1></th>
            <th><p1>&ensp;&ensp;&ensp;</p1></th>
            <th><p1> Le pack silver va te permettre de t'offrir un petit plaisir sur notre site à 49.99 euros, où tu vas recevoir 1.000 jetons en retour </p1></th>
            <th><p1>&ensp;&ensp;&ensp;</p1></th>
            <th><p1> le pack bronze t'offrira le moyen d'encherir sur notre application avec 100 jetons à seulement 9.99 euros </p1></th>
        </tr>
    </table>
    <table>
        <tr>
            <th><a href=\"https://www.paypal.com/fr/home\" class=\"btn btn-primary btn-lg btn-block\" type=\"button\">Buy pack Gold &ensp;<img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"> </a></th>
            <th><h1> &ensp;&ensp;&ensp;&ensp;&ensp; </h1></th>
            <th><a href=\"https://www.paypal.com/fr/home\" class=\"btn btn-primary btn-lg btn-block\" type=\"button\">Buy pack Silver &ensp; <img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"></a></th>
            <th><h1> &ensp;&ensp;&ensp;&ensp;&ensp;&ensp; </h1></th>
            <th><a href=\"https://www.paypal.com/fr/home\" class=\"btn btn-primary btn-lg btn-block\" type=\"button\">Buy pack Bronze <img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"></a></th>
        </tr>
    </table>
    <center>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/jetons.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    <center><h1> Pack jetons <img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"></h1></center>
    </br>
    </br>
    <center>
    <table>
         <tr>
            <th><img width=\"350\" height=\"400\" alt=\"\" src=\"http://getdrawings.com/vectors/gold-coin-vector-34.jpg\"></th>
            <th><h1> &ensp;</h1></th>
            <th><img width=\"350\" height=\"400\" alt=\"\" src=\"http://getdrawings.com/vectors/gold-coin-vector-11.jpg\" ></th>
            <th><h1> &ensp;</h1></th>
            <th><img width=\"350\" height=\"400\" alt=\"\" src=\"http://getdrawings.com/vectors/gold-coin-vector-33.jpg\"></th>
            <th></br></th>
         </tr>   
    </table>
    <table>
        <tr>
            <th><p1> Le pack gold va te permettre de vivre une expérience ultime sur notre site d'enchére, tu vas recevoir 5.000 jetons juste a 99.99 euros </p1></th>
            <th><p1>&ensp;&ensp;&ensp;</p1></th>
            <th><p1> Le pack silver va te permettre de t'offrir un petit plaisir sur notre site à 49.99 euros, où tu vas recevoir 1.000 jetons en retour </p1></th>
            <th><p1>&ensp;&ensp;&ensp;</p1></th>
            <th><p1> le pack bronze t'offrira le moyen d'encherir sur notre application avec 100 jetons à seulement 9.99 euros </p1></th>
        </tr>
    </table>
    <table>
        <tr>
            <th><a href=\"https://www.paypal.com/fr/home\" class=\"btn btn-primary btn-lg btn-block\" type=\"button\">Buy pack Gold &ensp;<img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"> </a></th>
            <th><h1> &ensp;&ensp;&ensp;&ensp;&ensp; </h1></th>
            <th><a href=\"https://www.paypal.com/fr/home\" class=\"btn btn-primary btn-lg btn-block\" type=\"button\">Buy pack Silver &ensp; <img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"></a></th>
            <th><h1> &ensp;&ensp;&ensp;&ensp;&ensp;&ensp; </h1></th>
            <th><a href=\"https://www.paypal.com/fr/home\" class=\"btn btn-primary btn-lg btn-block\" type=\"button\">Buy pack Bronze <img width=\"50\" height=\"50\" src=\"https://cdn.pixabay.com/photo/2017/10/17/02/31/coin-2859345_960_720.png\"></a></th>
        </tr>
    </table>
    <center>
{% endblock %}    ", "blog/jetons.html.twig", "C:\\Users\\33603\\Desktop\\project\\Project\\templates\\blog\\jetons.html.twig");
    }
}
