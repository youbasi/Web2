<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/anchor.html.twig */
class __TwigTemplate_206db51966007e757879f799a19defbc14fabc8523289d2b3055a9f580325e98 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/anchor.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/anchor.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog/anchor.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<center><h1> bienvenue sur nos enchéres</h1></center>
</br>
</br>
<center>
<table class=\"table table-hover\">
    <thead>
        <tr class=\"table-active\">
            <th>num <th>
            <th>image</th>
            <td>déscription</td>
            <td>date de fin</td>
            <td>Prix en €</td>
        </tr>

    </thead>
</table>    
</center>
<table class=\"table table-hover\">    
    <tbody>
        ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["produits"]) || array_key_exists("produits", $context) ? $context["produits"] : (function () { throw new RuntimeError('Variable "produits" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["produit"]) {
            // line 23
            echo "        <tr>
            <th scoope=\"col\"> 10 </th>
            <th scope=\"col\"><img  width=\"100\" height=\"50\" src=\"";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["produit"], "image", [], "any", false, false, false, 25), "html", null, true);
            echo "\"></br><p><small>réference</small></p></th>
            <th scope=\"col\">";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["produit"], "descriptif", [], "any", false, false, false, 26), "html", null, true);
            echo "<h6><br/>la valur du produit: ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["produit"], "prix", [], "any", false, false, false, 26), "html", null, true);
            echo "€<br/> le coût d'une anchére:....</h6> </th>
            <th scope=\"col\">date de fin</th>
            <th scope=\"col\"> ";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["produit"], "prix", [], "any", false, false, false, 28), "html", null, true);
            echo "</th>
        </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['produit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "    
    </tbody> 
</table>

<center>
    <div>
        <ul class=\"pagination pagination-sm\">
            <li class=\"page-item disabled\">
            <a class=\"page-link\" href=\"#\">&laquo;</a>
            </li>
            <li class=\"page-item active\">
            <a class=\"page-link\" href=\"#\">1</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">2</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">3</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">4</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">5</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">&raquo;</a>
            </li>
        </ul>
    </div>
</center>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/anchor.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 30,  108 => 28,  101 => 26,  97 => 25,  93 => 23,  89 => 22,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}
<center><h1> bienvenue sur nos enchéres</h1></center>
</br>
</br>
<center>
<table class=\"table table-hover\">
    <thead>
        <tr class=\"table-active\">
            <th>num <th>
            <th>image</th>
            <td>déscription</td>
            <td>date de fin</td>
            <td>Prix en €</td>
        </tr>

    </thead>
</table>    
</center>
<table class=\"table table-hover\">    
    <tbody>
        {% for produit in produits %}
        <tr>
            <th scoope=\"col\"> 10 </th>
            <th scope=\"col\"><img  width=\"100\" height=\"50\" src=\"{{produit.image}}\"></br><p><small>réference</small></p></th>
            <th scope=\"col\">{{produit.descriptif}}<h6><br/>la valur du produit: {{ produit.prix}}€<br/> le coût d'une anchére:....</h6> </th>
            <th scope=\"col\">date de fin</th>
            <th scope=\"col\"> {{ produit.prix }}</th>
        </tr>
        {% endfor %}    
    </tbody> 
</table>

<center>
    <div>
        <ul class=\"pagination pagination-sm\">
            <li class=\"page-item disabled\">
            <a class=\"page-link\" href=\"#\">&laquo;</a>
            </li>
            <li class=\"page-item active\">
            <a class=\"page-link\" href=\"#\">1</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">2</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">3</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">4</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">5</a>
            </li>
            <li class=\"page-item\">
            <a class=\"page-link\" href=\"#\">&raquo;</a>
            </li>
        </ul>
    </div>
</center>
{% endblock %}

", "blog/anchor.html.twig", "C:\\Users\\33603\\Desktop\\project\\Project\\templates\\blog\\anchor.html.twig");
    }
}
