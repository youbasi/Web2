<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/help.html.twig */
class __TwigTemplate_bf6f18efd1e0655fb059a2b420c1c71e31ef3fa24fe0ded1142e9fab98d3800c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/help.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/help.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog/help.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <center><h1>comment ca marche? </h1></center>
    </br>
    <h3>j'achéte aux enchéres </h3>
    <p1>pour acheter aux enchéres, je commence par m'inscrire en cliquant sur le bouton inscription sur 
    l'acceuil. Ensuite, vous indiquez votre mail, pseudo et mot de passe, vous placer votre offre et enfin vous effectuez le paiement selon l'une des méthodes  proposées. 
    Vous recevez par la suite votre lot au bout de 3 jours ouvrables.</p1>
    <table>
        <tr>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon1-135c23a04ef11800d21754737e8731599fa1aa28952a768bb3f5eb3f4b168927.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon2-9b7b2889eed76e2687c4c68e68cbc6e9e2b811bc4cc6d7b7f74b2893a80cd1cd.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon3-f303776239e88eedf6d993b73d09acd5cf98e97321a143f38b64944114ba195b.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon4-74bc55f3addb12832e15300b9861ed2d4672aae907b2f4c00baaf53a0add26e3.svg\"></th>
        </tr>
    </table>
    </br>
    <h3>je vends aux enchéres </h3>
    <p1>vous pouvez de même vendre vos propres objets via nos enchéres.
    vous possedez des objets de collection de qualité premium, vous pouvez facilement 
    les proposer dans nos ventes aux enchéres. Commencez par selectionner la vente pour laquelle 
    vous voulez proposer vos objets, ensuite décrivez les lots le mieux possible et ajoutez des photos nettes.
    Et enfin créez votre compte gratuit, en quelques clics </p1>
     <table>
        <tr>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon1-91c98cc1dda923d6dd2e448153b41b6a8cb03ce4236f57756bf08e59719a7dd2.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon2-8af6712b5f9ab472fc298aa4e893cc802f0e2cb67af969b933f85ffc5a0b1094.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon3-00c54a1b8b434f4efa15bfb0ee8a8489c1c1496275fd6bc2cb881795118f7dde.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon4-20f9555251982df8f9857b2bd405336ff37347e3d0d336f6f7f790212656e35c.svg\"></th>
        </tr>
    </table>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/help.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}
    <center><h1>comment ca marche? </h1></center>
    </br>
    <h3>j'achéte aux enchéres </h3>
    <p1>pour acheter aux enchéres, je commence par m'inscrire en cliquant sur le bouton inscription sur 
    l'acceuil. Ensuite, vous indiquez votre mail, pseudo et mot de passe, vous placer votre offre et enfin vous effectuez le paiement selon l'une des méthodes  proposées. 
    Vous recevez par la suite votre lot au bout de 3 jours ouvrables.</p1>
    <table>
        <tr>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon1-135c23a04ef11800d21754737e8731599fa1aa28952a768bb3f5eb3f4b168927.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon2-9b7b2889eed76e2687c4c68e68cbc6e9e2b811bc4cc6d7b7f74b2893a80cd1cd.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon3-f303776239e88eedf6d993b73d09acd5cf98e97321a143f38b64944114ba195b.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/buy_icon4-74bc55f3addb12832e15300b9861ed2d4672aae907b2f4c00baaf53a0add26e3.svg\"></th>
        </tr>
    </table>
    </br>
    <h3>je vends aux enchéres </h3>
    <p1>vous pouvez de même vendre vos propres objets via nos enchéres.
    vous possedez des objets de collection de qualité premium, vous pouvez facilement 
    les proposer dans nos ventes aux enchéres. Commencez par selectionner la vente pour laquelle 
    vous voulez proposer vos objets, ensuite décrivez les lots le mieux possible et ajoutez des photos nettes.
    Et enfin créez votre compte gratuit, en quelques clics </p1>
     <table>
        <tr>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon1-91c98cc1dda923d6dd2e448153b41b6a8cb03ce4236f57756bf08e59719a7dd2.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon2-8af6712b5f9ab472fc298aa4e893cc802f0e2cb67af969b933f85ffc5a0b1094.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon3-00c54a1b8b434f4efa15bfb0ee8a8489c1c1496275fd6bc2cb881795118f7dde.svg\"></th>
            <th></br></th>
            <th><img width=\"229\" height=\"125\" alt=\"\" src=\"https://cdn.catawiki.net/assets/help/ui/illustrations/sell_icon4-20f9555251982df8f9857b2bd405336ff37347e3d0d336f6f7f790212656e35c.svg\"></th>
        </tr>
    </table>
{% endblock %} 
   ", "blog/help.html.twig", "C:\\Users\\33603\\Desktop\\project\\Project\\templates\\blog\\help.html.twig");
    }
}
